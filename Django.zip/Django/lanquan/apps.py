from django.apps import AppConfig


class LanquanConfig(AppConfig):
    name = 'lanquan'
