from django.db import models


#定义图书模型类BookInfo
class BookInfo(models.Model):
    id = models.AutoField(primary_key=True)  # 创建自增的一个主键
    name = models.CharField(max_length=255, verbose_name='名称')
    price = models.CharField(max_length=255, verbose_name='Price')
    createdate = models.DateTimeField(verbose_name='添加日期')

    class Meta:
        db_table = 'tb_books'  # 指明数据库表名
        verbose_name = '图书'  # 在admin站点中显示的名称

        verbose_name_plural = verbose_name  # 显示的复数名称

    def __str__(self):
        """定义每个数据对象的显示信息"""
        return self.name