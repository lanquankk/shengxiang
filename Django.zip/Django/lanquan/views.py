import app as app
from django.shortcuts import render

# Create your views here.

from django.shortcuts import render#导入render模块
from django.http.response import JsonResponse
from lanquan import models#引用models
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
import logging
import datetime
from django.views.decorators.csrf import csrf_exempt
logger = logging.getLogger('stu')# 指定所用的logger



def index(request):
    return render(request,'index.html')#通过render模块把index.html这个文件返回到前端


def tb_book_json(request):
    response = {}
    """
    #不分页使用
    ret = models.BookInfo.objects.all().order_by("id")
    response["records"] = list(ret.values())
    response['total'] = models.BookInfo.objects.all().count()
    return JsonResponse(response)"""
    #分页
    offset = int(request.GET.get('offset'))
    limit = int(request.GET.get('limit'))
    keyword = request.GET.get('KEYW')
    if keyword:
        tb_book_list = models.BookInfo.objects.values('id', 'name', 'price').filter(name__contains=keyword).order_by("id")
    else:
        tb_book_list = models.BookInfo.objects.values('id', 'name', 'price').order_by("id")
    if tb_book_list:
        paginator = Paginator(tb_book_list, limit)
        try:
            page_object_list = paginator.page(offset / limit + 1)
            logger.info('获取数据成功,path：' + request.path)
        except PageNotAnInteger:
            logger.error('If page is not an integer, deliver first page.,path：' + request.path)
            page_object_list = paginator.page(1)
        except EmptyPage:
            logger.error('If page is out of range (e.g. 9999), deliver last page of results.,path：' + request.path)
            page_object_list = paginator.page(paginator.num_pages)

    """rows = []
    for item in page_object_list:
        # 将数组中的每个元素提取出来拼接为rows的内容
        rows.append({'id': item['id'], 'name': item['name'], 'price': item['price']})"""

    response["records"] = page_object_list.object_list
    if keyword:
        response['total'] = models.BookInfo.objects.filter(name__contains=keyword).count()
    else:
        response['total'] = models.BookInfo.objects.all().count()
    return JsonResponse(response)


#edit修改获取数据
@csrf_exempt
def tb_book_info(request):
    response = {}
    keyid = int(request.POST.get('id'))
    response['row'] = list(models.BookInfo.objects.filter(id=keyid).values('id', 'name', 'price'))
    return JsonResponse(response)


#add,edit 保存
@csrf_exempt
def tb_book_save(request):
    response = {}
    keyid = int(request.POST.get('id'))
    name = request.POST.get('name')
    price = request.POST.get('price')
    if keyid == 0:
        #print("添加:" + str(name) + ";" + str(price))
        entity = models.BookInfo()
        entity.name = name
        entity.price = price
        entity.createdate = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        # 调用save则保存数据到数据库中
        try:
            entity.save()
            response['row'] = "ok"
        except MyError as e:
            response['row'] = "error"
            response['message'] = e.msg
    else:
        #print("修改:" + str(keyid) + ";" + str(name) + ";" + str(price))
        try:
            models.BookInfo.objects.filter(id=keyid).update(name=name, price=price)
            response['row'] = "ok"
        except MyError as e:
            response['row'] = "error"
            response['message'] = e.msg
    return JsonResponse(response)


#删除，批量删除根据ID
@csrf_exempt
def tb_book_del(request):
    response = {}
    ids = request.POST.get('ids')
    try:
        models.BookInfo.objects.extra(where=['id IN (' + ids + ')']).delete()
        response['row'] = "ok"
    except MyError as e:
        response['row'] = "error"
        response['message'] = e.msg
    return JsonResponse(response)


class MyError(Exception):
    def __init__(self, msg):
        self.msg = msg

    def __str__(self):
        return self.msg

